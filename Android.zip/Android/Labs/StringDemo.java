package sec.Android;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String m1 = "HelloWorld";
        System.out.println(m1.substring(0,3));
        System.out.println(m1.substring(1,3));;
        String m2 = m1.substring(0,3) + "p!";
        String m3 = "Help!";
        String m4 = "HelloWorld";
        String m5 = "HelloWorld";
        System.out.println("m1 : " + m1);
        System.out.println("m2 : " + m2);
        System.out.println("m3 : " + m3);
        System.out.println("m4 : " + m4);
        System.out.println("m5 : " + m5);

        boolean b1 = (m1 == m2);
        boolean b2 = m1.equals(m2);
        boolean b3 = (m2 == m3);
        boolean b4 = m2.equals(m3);
        boolean b5 = (m4 == m5);
        boolean b6 = m4.equals(m5);
        boolean b7 = (m1 == m4);
        boolean b8 = m1.equals(m4);
        System.out.println("Result " + b1 + "  " +b2);
        System.out.println("Result " + b3 + "  " +b4);
        System.out.println("Result " + b5 + "  " +b6);
        System.out.println("Result " + b7 + "  " +b8);


    }
}
